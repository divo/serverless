# frozen_string_literal: true

module HTTParty
  VERSION = '0.21.0'
end
