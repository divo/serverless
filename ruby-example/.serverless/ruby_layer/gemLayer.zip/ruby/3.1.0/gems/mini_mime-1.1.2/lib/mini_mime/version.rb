# frozen_string_literal: true
module MiniMime
  VERSION = "1.1.2"
end
